import React from 'react';

const Content = () => {
    return (
        <div id="page-content-wrapper">
            <div className="container-fluid">
                <h1 className="mt-4">Welcome to My App</h1>
                <p>This is a simple React app with Bootstrap.</p>
            </div>
        </div>
    );
}

export default Content;