const Protocol = () => {
  return (
    <div>
      <h1>Protocol</h1>
    </div>
  );
};

export default Protocol;
