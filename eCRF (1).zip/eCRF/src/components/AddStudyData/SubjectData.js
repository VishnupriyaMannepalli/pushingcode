import { useEffect, useState } from "react";
import { Form, Button } from 'react-bootstrap';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

const SubjectData = ({subjectData, setSubjectData}) => {

  return (
    <>
      <div className="row">
        <div className="col-3">
          <Form.Group controlId="formBasicText1">
            <Form.Label>Subject Id</Form.Label>
            <Form.Control type="text" placeholder="Enter text" value={subjectData?.subjectId} onChange={(e) => setSubjectData({ ...subjectData,subjectId: e.target.value })} />
          </Form.Group>
        </div>
        <div className="col-3">
          <Form.Group controlId="formBasicText1">
            <Form.Label>Subject Counter</Form.Label>
            <Form.Control type="text" placeholder="Enter text" readOnly disabled value={subjectData?.subjectCounter + 1} onChange={(e) => setSubjectData({ ...subjectData,subjectCounter: e.target.value })} />
          </Form.Group>
        </div>
        <div className="col-3">
          <Form.Group controlId="formBasicText1">
            <Form.Label>Year of Birth (if available)</Form.Label>
            <Form.Control type="text" placeholder="Enter text" value={subjectData?.subjectYear} onChange={(e) => {
              const inputValue = e.target.value;
              if (/^\d{0,4}$/.test(inputValue)) {
                setSubjectData({ ...subjectData,subjectYear: e.target.value })
              }
            }} disabled={subjectData?.subjectUnknown[0] === "Unknown"} />
          </Form.Group>
        </div>
        <div className="col-3">
          <Form.Group controlId="formBasicText1">
            <Form.Label>OR Unknown</Form.Label>
            <Form.Check type="checkbox" placeholder="Enter text" checked={subjectData?.subjectUnknown.includes("Unknown")} onChange={() => 
              {
                if (subjectData?.subjectUnknown === "Unknown") {
                  setSubjectData({ ...subjectData, subjectYear: '' })
                }
                let updatedValues;
                if (subjectData?.subjectUnknown.includes('Unknown')) {
                  updatedValues = subjectData?.subjectUnknown.filter((item) => item !== 'Unknown');
                } else {
                  updatedValues = [...subjectData?.subjectUnknown, 'Unknown'];
                }
                setSubjectData({ ...subjectData, subjectUnknown: ['Unknown'] });
                setSubjectData({ ...subjectData, subjectYear: '' })
              }}  />
          </Form.Group>
        </div>
      </div>
    </>
  );
};

export default SubjectData;
