import { useEffect, useState } from "react";
import moment, { duration } from "moment";
import { useNavigate } from "react-router-dom";
import Cookies from "js-cookie";
import { Form, Button, Card, Accordion } from 'react-bootstrap';
import StudyData from "./StudyData";
import SubjectData from "./SubjectData";

const AddStudyData = () => {
  const studyDataInputFields = [
    { id: 1, label: 'Study Data' },
    { id: 2, label: 'Subject Data' },
    { id: 3, label: 'Baseline Characteristics' },
    { id: 4, label: 'Laboratory Parameters most recent and within 6 months of the HCC diagnosis' },
    { id: 5, label: 'Comorbidities' },
    { id: 6, label: 'HCC Diagnosis Information' },
    { id: 7, label: 'HCC Staging' },
    { id: 8, label: 'Chronic Liver Disease (CLD)Etiology' },
    { id: 9, label: 'HCC Outcome' },
    { id: 10, label: 'Screening Questions' },
    { id: 11, label: 'HIV-Specific Lab Data within 6 months of HCC diagnosis' },
    { id: 12, label: 'Hepatitis C virus (HCV) data within 6 months of HCC diagnosis' },
    { id: 13, label: 'Hepatitis B virus (HBV) data within 6 months of HCC diagnosis' },
    { id: 14, label: 'Logs' }
  ];

  const [studyData, setStudyData] = useState({ siteId: '', projectNo: '', studyDate: new Date(), studyTitle: '' });
  const [subjectData, setSubjectData] = useState({"subjectId": "", "otherCheck": "", "subjectYear": "", "residencyCity": "", "subjectGender": "", "residencyState": "", "subjectCounter": 0, "subjectUnknown": [], "placeOfBirthCity": "", "subjectOtherText": "", "placeOfBirthState": ""});

  return (
    <>
    <div className="p-5">
      <Accordion defaultActiveKey="0">
        {studyDataInputFields.map((field, index) => (
          <Card key={field.id} className="p-3">
            <Accordion.Item eventKey={field.id.toString()}>
              <Accordion.Header>
                <span>{field.label}</span>
              </Accordion.Header>
              <Accordion.Collapse eventKey={field.id.toString()}>
                <Card.Body>
                  <div>
                    { field.id === 1 && <StudyData studyData={studyData} setStudyData={setStudyData} /> }
                    { field.id === 2 && <SubjectData subjectData={subjectData} setSubjectData={setSubjectData} /> }
                  </div>
                </Card.Body>
              </Accordion.Collapse>
            </Accordion.Item>
          </Card>
        ))}
      </Accordion>
      <div className="d-flex justify-content-end pt-3">
        <button className="btn btn-primary">Submit</button>
      </div>
    </div>
    </>
  );
};

export default AddStudyData