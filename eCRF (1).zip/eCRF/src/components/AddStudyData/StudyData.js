import { useEffect, useState } from "react";
import { Form, Button } from 'react-bootstrap';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

const StudyData = ({studyData, setStudyData}) => {

  return (
    <>
      <div className="row">
        <div className="col-3">
          <Form.Group controlId="formBasicText1">
            <Form.Label>Study Title</Form.Label>
            <Form.Control type="text" placeholder="Enter text" value={studyData?.studyTitle} onChange={(e) => setStudyData({ ...studyData,studyTitle: e.target.value })} />
          </Form.Group>
        </div>
        <div className="col-3">
          <Form.Group controlId="formBasicText1">
            <Form.Label>Project Number</Form.Label>
            <Form.Control type="text" placeholder="Enter text" value={studyData?.projectNo} onChange={(e) => setStudyData({ ...studyData,projectNo: e.target.value })} />
          </Form.Group>
        </div>
        <div className="col-3">
          <Form.Group controlId="formBasicText1">
            <Form.Label>Site ID/Name</Form.Label>
            <Form.Control type="text" placeholder="Enter text" value={studyData?.siteId} onChange={(e) => setStudyData({ ...studyData,siteId: e.target.value })} />
          </Form.Group>
        </div>
        <div className="col-3">
          <Form.Group controlId="formBasicText1">
            <Form.Label>Study Date</Form.Label>
            <br />
            <DatePicker className="form-control" value={studyData?.studyDate} onChange={(date) => setStudyData({ ...studyData,studyDate: date })} />
          </Form.Group>
        </div>
      </div>
    </>
  );
};

export default StudyData;
