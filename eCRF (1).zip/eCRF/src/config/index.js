const config = {
  "apiUrl":"http://localhost:8080"
  // "apiUrl": "http://52.8.204.207:8080"
}

export default config;